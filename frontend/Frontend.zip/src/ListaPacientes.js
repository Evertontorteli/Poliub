import React, { useState, useEffect } from 'react';
import axios from 'axios';

function ListaPacientes({ reloadKey, onEditar }) {
  const [pacientes, setPacientes] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    setCarregando(true);
    axios.get('/api/pacientes')
      .then(res => {
        setPacientes(res.data);
        setCarregando(false);
      })
      .catch(() => setCarregando(false));
  }, [reloadKey]);

  const handleDeletar = (id) => {
    if (window.confirm('Deletar este paciente?')) {
      axios.delete(`/api/pacientes/${id}`)
        .then(() => setPacientes(prev => prev.filter(p => p.id !== id)));
    }
  };

  if (carregando) return <p>Carregando pacientes...</p>;
  if (pacientes.length === 0) return <p>Nenhum paciente cadastrado.</p>;

  return (
    <div className="mx-auto py-2 px-2">
      {/*<h1 className="text-2xl font-bold mb-6 text-[#1d3557]">Lista de Pacientes</h1>*/}
      <div className="bg-white rounded-2xl p-2">
        {/* Cabeçalho das colunas (desktop) */}
        <div className="hidden md:grid grid-cols-3 gap-x-4 px-2 py-2 bg-gray-100 rounded-t-xl font-semibold text-gray-600 mb-2">
          <span>Nome</span>
          <span>Telefone</span>
          <span className="text-right">Ações</span>
        </div>
        {/* Lista */}
        <div className="space-y-3">
          {pacientes.map((p) => (
            <div
              key={p.id}
              className="flex flex-col md:grid md:grid-cols-3 gap-y-1 gap-x-4 items-center bg-gray-50 rounded-xl px-4 md:px-2 py-2 shadow-sm hover:bg-gray-100 transition"
            >
              <div className="w-full font-medium text-gray-800 truncate">{p.nome}</div>
              <div className="w-full text-gray-500">{p.telefone}</div>
              <div className="flex flex-row justify-end gap-2 w-full md:justify-end">
                <button
                  onClick={() => onEditar(p)}
                  className="px-4 py-1 rounded-lg bg-blue-100 text-blue-800 hover:bg-blue-200 font-semibold transition"
                >
                  Editar
                </button>
                <button
                  onClick={() => handleDeletar(p.id)}
                  className="px-4 py-1 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 font-semibold transition"
                >
                  Deletar
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default ListaPacientes;
