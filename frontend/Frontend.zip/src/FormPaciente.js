// src/components/FormPaciente.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

function FormPaciente({ onNovoPaciente, pacienteEditando, onFimEdicao }) {
  const [nome, setNome] = useState('');
  const [telefone, setTelefone] = useState('');
  const [mensagem, setMensagem] = useState('');

  // Carrega dados quando estiver editando
  useEffect(() => {
    if (pacienteEditando) {
      setNome(pacienteEditando.nome || '');
      setTelefone(formatarTelefone(pacienteEditando.telefone || ''));
    } else {
      setNome('');
      setTelefone('');
    }
    setMensagem('');
  }, [pacienteEditando]);

  // Função para validar nome: pelo menos duas palavras, cada uma com >= 2 letras
  function validarNomeCompleto(valor) {
    const partes = valor.trim().split(/\s+/);
    if (partes.length < 2) return false;
    return partes.every(p => p.length >= 2 && /^[A-Za-zÀ-ÖØ-öø-ÿ]+$/.test(p));
  }

  // Função para formatar telefone enquanto digita: (XX) XXXXX-XXXX
  function formatarTelefone(campo) {
    // Remove tudo que não for número
    const digitos = campo.replace(/\D/g, '');

    // Se tiver até 2 dígitos: só coloca parênteses abertos
    if (digitos.length <= 2) {
      return digitos.replace(/^(\d{0,2})/, '($1');
    }
    // Se tiver de 3 até 6 digitos: (XX) XXX
    if (digitos.length <= 6) {
      return digitos
        .replace(/^(\d{2})(\d{0,4})/, '($1) $2');
    }
    // Se tiver 7 ou mais dígitos: (XX) XXXXX-XXXX
    return digitos
      .replace(/^(\d{2})(\d{5})(\d{0,4}).*/, '($1) $2-$3');
  }

  // Handler para nome
  const handleNomeChange = e => {
    setNome(e.target.value);
  };

  // Handler para telefone, que aplica a máscara
  const handleTelefoneChange = e => {
    const valor = e.target.value;
    const formatado = formatarTelefone(valor);
    setTelefone(formatado);
  };

  const handleSubmit = e => {
    e.preventDefault();
    setMensagem('');

    // Validações
    if (!validarNomeCompleto(nome)) {
      setMensagem('Informe nome e sobrenome, cada um com ao menos 2 letras.');
      return;
    }

    // Verifica se telefone tem 10 ou 11 dígitos
    const somenteDigitos = telefone.replace(/\D/g, '');
    if (!(somenteDigitos.length === 10 || somenteDigitos.length === 11)) {
      setMensagem('Telefone inválido. Use 10 ou 11 dígitos.');
      return;
    }

    const dados = {
      nome: nome.trim(),
      // Envia telefone sem formatação para o backend
      telefone: somenteDigitos
    };

    if (pacienteEditando) {
      axios
        .put(`/api/pacientes/${pacienteEditando.id}`, dados)
        .then(() => {
          setMensagem('Paciente atualizado com sucesso!');
          onNovoPaciente();
          // Mantém o modal aberto até o usuário fechar manualmente
        })
        .catch(() => {
          setMensagem('Erro ao atualizar paciente.');
        });
    } else {
      axios
        .post('/api/pacientes', dados)
        .then(() => {
          setMensagem('Paciente cadastrado com sucesso!');
          onNovoPaciente();
          setNome('');
          setTelefone('');
        })
        .catch(() => {
          setMensagem('Erro ao cadastrar paciente.');
        });
    }
  };

  return (
    <div className="bg-white mx-auto max-w-lg rounded-2xl p-6">
      <form onSubmit={handleSubmit} autoComplete="off">
        <h2 className="text-2xl font-bold mb-6 text-gray-800">
          {pacienteEditando ? 'Editar Paciente' : 'Novo Paciente'}
        </h2>

        {/* Campo Nome */}
        <div className="mb-6">
          <label className="block mb-2 font-medium text-gray-700">
            Nome
            <input
              className="w-full border rounded px-3 py-2 mt-1"
              required
              value={nome}
              onChange={handleNomeChange}
              placeholder="Nome e sobrenome"
              type="text"
            />
          </label>
        </div>

        {/* Campo Telefone */}
        <div className="mb-6">
          <label className="block mb-2 font-medium text-gray-700">
            Telefone
            <input
              className="w-full border rounded px-3 py-2 mt-1"
              required
              value={telefone}
              onChange={handleTelefoneChange}
              placeholder="(XX) XXXXX-XXXX"
              type="tel"
            />
          </label>
        </div>

        {/* Botões */}
        <div className="flex flex-col md:flex-row gap-4">
          <button
            type="submit"
            className="bg-[#1A1C2C] hover:bg-[#3B4854] text-white font-bold py-2 px-6 rounded-full"
          >
            {pacienteEditando ? 'Atualizar' : 'Cadastrar'}
          </button>
          {pacienteEditando && (
            <button
              type="button"
              className="bg-[#DA3648] text-white hover:bg-[#BC3140] px-4 py-2 rounded-full"
              onClick={onFimEdicao}
            >
              Cancelar
            </button>
          )}
        </div>

        {/* Feedback de sucesso/erro */}
        {mensagem && (
          <p className="mt-4 text-red-600">
            {mensagem}
          </p>
        )}
      </form>
    </div>
  );
}

export default FormPaciente;
